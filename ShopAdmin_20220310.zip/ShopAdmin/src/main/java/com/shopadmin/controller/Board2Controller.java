package com.shopadmin.controller;

import java.io.File;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.DiskFileUpload;
import org.apache.commons.fileupload.FileItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.shopadmin.domain.Board2VO;
import com.shopadmin.service.Board2Service;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/board2/")
public class Board2Controller {

	@Setter(onMethod_ = @Autowired)
	private Board2Service service;
	
//	@GetMapping("/list")
//	public void list(Model model, PageDTO page, @RequestParam("user") String user, 
//			@RequestParam("age") int age) {	// 객체를 저장해서 jsp 파일로 전송
//		// list.jsp에 데이터를 전달
//		if(user == null) user="이순신";
//		model.addAttribute("list", service.getList(page));	// getList로 조회한 내용을 리스트 변수로 전달model 객체
//		int total = service.getTotalCount();
//		PageViewDTO pageview = new PageViewDTO(page, total);
//		log.info(pageview);
//		model.addAttribute("pageview", pageview);
//		log.info("______________________________________");
//		log.info(user);
//		log.info(age + 10);
//		log.info("______________________________________");
//		model.addAttribute("user", user);
//		model.addAttribute("age", age);
//	}
//	
	@GetMapping("/insert")
	public void insert() {
		// 페이지를 호출만 함
	}
//	
//	@PostMapping("/insert")
//	public String insert(Board2VO board) {
//		log.info(board);
//		service.insert(board);
//		return "redirect:/board/list";
//	}
	
//	@GetMapping("/insert")
//	public void imgupload(ProductVO product, Model model) {
//		log.info(product);
//		model.addAttribute("p_code", product.getP_code());
//	}
	
	@PostMapping("/insert")
	public void imgupload(HttpServletRequest request) {
		DiskFileUpload upload =  new DiskFileUpload();
		try {
			List items = upload.parseRequest(request);	// 웹브라우저 전송 객체 생성해서 업로드 컴포넌트에 전달
			Iterator params = items.iterator();	// 반복자 생성
			String filepath = "C:\\myWorkSpace\\runJsp\\pds";
			Board2VO board = new Board2VO();
			while(params.hasNext()) {	// form 객체가 있을 경우
				FileItem item = (FileItem)params.next();	// 폼 경식 객체를 변수에 저장
				if(item.isFormField()) {	// 파일 형식이 아니라면
					//p_code = item.getString();	// 파일보다 먼저 반환 됨
					String fieldname = item.getFieldName();
					String fieldvalue =  item.getString("utf-8");
					log.info(fieldname + ":" + fieldvalue);
					if(fieldname.equals("b_subject")) {
						board.setB_subject(fieldvalue);
					} else if(fieldname.equals("b_name")) {
						board.setB_name(fieldname);
					} else if(fieldname.equals("b_contents")) {
						board.setB_contents(fieldvalue);
					}
				} else {	// 바이너리 파일이라면 
					String fname = item.getName();
					if(fname != "") {
						board.setB_file(fname);
						File file = new File(filepath + "/");	// 파일객체 생성
						item.write(file);						
					}
				}
			}
			log.info(board);
//			service.insert(board);
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
