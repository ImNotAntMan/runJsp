package com.it.mapper;

public interface TimeMapper {
	public String getTime();
}
