package com.it.service;

import org.springframework.stereotype.Service;

import com.it.domain.CartmainVO;

@Service
public interface OrderService {
	
	public void orderproc(CartmainVO cartmain);
	
}
